import string;
import re;
import random
import math
import numpy as np
from time import time
import smart_open
smart_open.open = smart_open.smart_open
import gensim
from gensim.models import Word2Vec
import pickle as pkl
from itertools import *
embed_d = 128
window_s = 5


def load_data(path="/Users/subhadramokashe/BrandeisCoursework/deeplearning/assignment3/dataset/paper_abstract.pkl", maxlen = None, n_words = 600000, sort_by_len = False):
    f = open(path, 'rb')
    content_set = pkl.load(f,encoding='latin1')
    f.close()

    def remove_unk(x):
        return [[1 if w >= n_words else w for w in sen] for sen in x] #we are only considering 600000 words. All the other words are given the token 1. The dataset already has a lot of 1s.

    content_set_x, content_set_y = content_set
    #print(max(content_set_x))
    #print((content_set_x[1]))
    content_set_x = remove_unk(content_set_x)
    #print(content_set_x[1])
    #print(content_set_x)
    list_len = [len(i) for i in content_set_x]
    print(max(list_len))
    
    for i in range(len(content_set_x)):
        if len(content_set_x[i]) > 2000:
            content_set_x[i] = content_set_x[i][:2000]
        else:
            pad_len = 2000 - len(content_set_x[i])
            content_set_x[i] = np.lib.pad(content_set_x[i], (0, pad_len), 'constant', constant_values=(0,0))
    
    content_set_x = [[str(x) for x in sen]for sen in content_set_x]
    #print(content_set_x)
    def len_argsort(seq):
        return sorted(range(len(seq)), key=lambda x: len(seq[x]))

    if sort_by_len:
        sorted_index = len_argsort(content_set_x)
        content_set_x = [content_set_x[i] for i in sorted_index]

    return content_set_x

yy = load_data()
#print(len(yy[0]))
def word2vec():
    # generate word embedding file: word_embeddings.txt
    wordsx = load_data()
    word_emb = Word2Vec(wordsx,min_count=1,size=embed_d ,window =window_s, sg =1)
    print(word_emb)
    #word_emb.("word2vec.bin")
    word_emb.save('model.bin')
    word_emb.wv.save_word2vec_format('word_embeddings.txt')
    return

word2vec()







