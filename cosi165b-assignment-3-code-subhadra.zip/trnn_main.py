import numpy as np
import matplotlib.pyplot as plt
import scipy
import trnn_utils as U
import torch
import smart_open
import os
smart_open.open = smart_open.smart_open
import gensim
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import warnings
warnings.filterwarnings("ignore", category=FutureWarning)
from torch.utils.data import TensorDataset, DataLoader
from torch import Tensor
torch.manual_seed(0)

def create_dataset(train_data_x,train_data_y):
    #print(Tensor(train_data_y.T[:,0]))
    dataset = torch.utils.data.TensorDataset( Tensor(train_data_x), Tensor(train_data_y) )
    return dataset

# model train
def model_train(all_data, word_embed, train_data_x, train_data_y, test_data_x, test_data_y):
    all_datax = Tensor(all_data).type(torch.LongTensor)
    #net = U.Text_Encoder2(all_datax,word_embed) #with mean pooling
    net = U.Text_Encoder2(all_datax,word_embed) #last hidden state
    print("Hi")
    trainset = create_dataset(train_data_x, train_data_y)
    wei = [0,0,0,0,0]
    #optimizer = optim.Adam(net.parameters(), lr=0.001, betas=(0.00, 0.00), eps=1e-11, weight_decay=0, amsgrad=False)
    optimizer = optim.Adam(net.parameters(), lr=0.001, betas=(0.1, 0.19), eps=1e-09, weight_decay=0, amsgrad=False)
    for i in range(5):
        wei[i]= train_data_y.count(i)
    parameters = filter(lambda p: p.requires_grad, net.parameters())    
    #optimizer = optim.SGD(parameters, lr=0.1, momentum=0.1, dampening=.9, weight_decay=1, nesterov=False)
    wei = np.array(wei)
    criterion = nn.CrossEntropyLoss(weight = Tensor([1.0,1.1,1.0,1.0,1.0]))
    #criterion = nn.CrossEntropyLoss()
    epoch_num = 100
    loss_e = np.zeros((epoch_num,1))
    trainloader = torch.utils.data.DataLoader(trainset, batch_size=20,shuffle=True)
    accuracytr_e = np.zeros((epoch_num,1))
    accuracyts_e = np.zeros((epoch_num,1))
    net.train()
    for epoch in range(epoch_num):  # loop over the dataset multiple times
            running_loss = 0.0
            for i, data in enumerate(trainloader, 0):
                    # get the inputs; data is a list of [inputs, labels]
                    inputs, labels = data
                    #print(inputs)
                    inputs = inputs.float()
                    labels = labels.float()
                    labels = labels.type(torch.LongTensor)
                    # zero the parameter gradients
                    optimizer.zero_grad()
                    # forward + backward + optimize
                    #print(inputs.size())
                    #inputs= inputs.requires_grad_()
                    outputs = (net(inputs))
                    #print(outputs.size())
                    loss= criterion(outputs, labels)
                    loss.backward()
                    optimizer.step()
                    running_loss += loss.item()
                    if i % 1000 == 2:    # print every  epoch
                            print('[%d, %5d] loss: %.3f' %(epoch + 1, i + 1, running_loss / 1000))
                            loss_e[epoch] = running_loss/1000
                            running_loss = 0.0
            accuracystr = model_test(train_data_x, train_data_y, net, epoch_num)
            accuracysts = model_test(test_data_x, test_data_y, net, epoch_num)
            accuracytr_e[epoch] = accuracystr
            accuracyts_e[epoch] = accuracysts
    print('Finished Training')
    return loss_e, accuracytr_e, accuracyts_e
    
	



# model test: can be called directly in model_train
def model_test(test_data_x, test_data_y, net, epoch_num):
        correct = 0
        total = 0
        ep = epoch_num
        testset = create_dataset(test_data_x, test_data_y)
        testloader = torch.utils.data.DataLoader(testset, batch_size=20,shuffle=False)
        with torch.no_grad():
                for data in testloader:
                        images, labels = data
                        outputs = net(images)
                        #print(labels)
                        outputs = torch.sigmoid(outputs)
                        #print(outputs.size())
                        #outputs = torch.sigmoid(outputs)
                        _, predicted = torch.max(outputs,1)
                        #print(predicted)
                        total += labels.size(0)
                        correct += (predicted == labels).sum().item()
                print('Accuracy of the network on the dataset: %d %%' % (100 * correct / total))
        accu = 100 * correct / total
        return accu
                
"""        

def model_train2(all_data, word_embed, train_data_x, train_data_y, test_data_x, test_data_y):
    all_datax = Tensor(all_data).type(torch.LongTensor)
    net = U.Text_Encoder2(all_datax,word_embed)
    print("Hi")
    trainset = create_dataset(train_data_x, train_data_y)
    wei = [0,0,0,0,0]
    optimizer = optim.Adam(net.parameters(), lr=0.001, betas=(0.1, 0.999), eps=1e-09, weight_decay=0, amsgrad=False)
    for i in range(5):
        wei[i]= train_data_y.count(i)
    parameters = filter(lambda p: p.requires_grad, net.parameters())    
    #optimizer = optim.SGD(parameters, lr=0.1, momentum=0.1, dampening=.9, weight_decay=1, nesterov=False)
    wei = np.array(wei)
    criterion = nn.CrossEntropyLoss(weight = Tensor([1.0,1.1,1.0,1.0,1.0]))
    #criterion = nn.CrossEntropyLoss()
    epoch_num = 100
    loss_e = np.zeros((epoch_num,1))
    trainloader = torch.utils.data.DataLoader(trainset, batch_size=20,shuffle=True)
    accuracytr_e = np.zeros((epoch_num,1))
    accuracyts_e = np.zeros((epoch_num,1))
    net.train()
    for epoch in range(epoch_num):  # loop over the dataset multiple times
            running_loss = 0.0
            for i, data in enumerate(trainloader, 0):
                    # get the inputs; data is a list of [inputs, labels]
                    inputs, labels = data
                    #print(inputs)
                    inputs = inputs.float()
                    labels = labels.float()
                    labels = labels.type(torch.LongTensor)
                    # zero the parameter gradients
                    optimizer.zero_grad()
                    # forward + backward + optimize
                    #print(inputs.size())
                    #inputs= inputs.requires_grad_()
                    outputs = (net(inputs))
                    #print(labels,outputs)
                    loss= criterion(outputs, labels)
                    loss.backward()
                    optimizer.step()
                    running_loss += loss.item()
                    if i % 1000 == 2:    # print every  epoch
                            print('[%d, %5d] loss: %.3f' %(epoch + 1, i + 1, running_loss / 1000))
                            loss_e[epoch] = running_loss/1000
                            running_loss = 0.0
            accuracystr = model_test(train_data_x, train_data_y, net, epoch_num)
            accuracysts = model_test(test_data_x, test_data_y, net, epoch_num)
            accuracytr_e[epoch] = accuracystr
            accuracyts_e[epoch] = accuracysts
    print('Finished Training')
    return loss_e, accuracytr_e, accuracyts_e
    
    
"""

if __name__ == '__main__':
	# load datasets
	print("Hi")
	input_data = U.input_data()
	print("Hi")

	all_data, train_data, test_data = input_data.load_text_data()
	train_data_x = train_data[0] # map content by id
	train_data_y = train_data[1]
	test_data_x = test_data[0] # map content by id
	test_data_y = test_data[1]
	#print(test_data)

	word_embed,vocbn,vocid = input_data.load_word_embed()
	#print(word_embed)
	#print(word_embed.type())

	# model train (model test function can be called directly in model_train)
	losse, acctrn, acctst= model_train(all_data, word_embed, train_data_x, train_data_y, test_data_x, test_data_y)
	
	os.environ['KMP_DUPLICATE_LIB_OK']='True'

	plt.plot(acctrn, label = "training data")
	plt.plot(acctst, label = "test data")
	plt.xlabel("epoch #")
	plt.ylabel("train accuracy")
	plt.legend()
	plt.show()

	plt.plot(losse)
	plt.xlabel("epoch #")
	plt.ylabel("loss")
	plt.legend()
	plt.show()
        
	
	
	
	






