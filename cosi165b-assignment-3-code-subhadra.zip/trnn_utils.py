import numpy as np
import pickle as pkl
import re
import codecs
import torch
import torch.nn as nn
import torch.nn.functional as F
import smart_open
smart_open.open = smart_open.smart_open
import gensim
import tensorflow as tf
from gensim.models import Word2Vec
from gensim.test.utils import datapath
from gensim.models import KeyedVectors
from gensim.scripts.glove2word2vec import glove2word2vec
from itertools import *
import warnings
warnings.filterwarnings("ignore", category=FutureWarning)
embed_d = 128
window_s = 5
import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
#import torchtext
torch.manual_seed(0)
c_len = 100
embed_d = 128
from gensim.test.utils import datapath, get_tmpfile
from gensim.models import KeyedVectors
from gensim.scripts.glove2word2vec import glove2word2vec
glove_file = datapath('/Users/subhadramokashe/BrandeisCoursework/deeplearning/assignment3/code/word_embeddings.txt')
tmp_file = get_tmpfile('test_word2vec.txt')
_ = glove2word2vec(glove_file, tmp_file)

# data class
class input_data():
    def load_text_data(self, word_n = 100000):
        f = open('../dataset/paper_abstract.pkl', 'rb')
        p_content_set = pkl.load(f, encoding = 'latin1')
        f.close()

        p_label = [0] * 21044
        label_f = open('../dataset/paper_label.txt', 'r')
        for line in label_f:
            line = line.strip()
            label_s = re.split('\t',line)
            p_label[int(label_s[0])] = int(label_s[1])
        label_f.close()

        def remove_unk(x):
            return [[1 if w >= word_n else w for w in sen] for sen in x]

        p_content, p_content_id = p_content_set
        p_content = remove_unk(p_content)

        # padding with max len 
        for i in range(len(p_content)):
            if len(p_content[i]) > c_len:
                p_content[i] = p_content[i][:c_len]
            else:
                pad_len = c_len - len(p_content[i])
                p_content[i] = np.lib.pad(p_content[i], (0, pad_len), 'constant', constant_values=(0,0))

        p_id_train = []
        p_content_train = []
        p_label_train = []
        p_id_test = []
        p_content_test = []
        p_label_test = []
        for j in range(len(p_content)):
            if j % 10 in (3, 6, 9):
                p_id_test.append(p_content_id[j])
                #p_content_test.append(p_content[j])
                p_label_test.append(p_label[j])
            else:
                p_id_train.append(p_content_id[j])
                #p_content_train.append(p_content[j])
                p_label_train.append(p_label[j])

        p_train_set = (p_id_train, p_label_train)
        p_test_set = (p_id_test, p_label_test)
        print(len(p_content))

        return p_content, p_train_set, p_test_set


    def load_word_embed(self):
        glove_file = "word_embeddings.txt"
        word_vectors = {}
        words = []
        with open(glove_file) as f:
            for line in f:
                split = line.split()
                words.append(split[0])
                word_vectors[split[0]] = np.array([float(x) for x in split[1:]])
        print(len(word_vectors))
        vocab_size = len(word_vectors) + 1
        vocab_to_idx = {}
        vocab = [""]
        W = np.zeros((vocab_size, embed_d), dtype="float32")
        W[0] = np.zeros( embed_d, dtype='float32') # adding a vector for padding
        i = 1
        for word in words:
            if word in words:
                W[i] = word_vectors[word]
            else:
                W[i] = np.random.uniform(-0.25,0.25, embed_d)
            vocab_to_idx[word] = i
            vocab.append(word)
            i += 1   
        return W, np.array(vocab), vocab_to_idx
        


#text RNN Encoder
class Text_Encoder(nn.Module):
    def __init__(self, p_content, word_embed):
        # two input: p_content - abstract data of all papers, word_embed - pre-trained word embedding 
        super(Text_Encoder, self).__init__()
        weight = torch.FloatTensor(word_embed)
        #print(weight.size())
        self.embedding = nn.Embedding.from_pretrained(weight)
        #self.embeddings.weight.requires_grad = False ## freeze embeddings
        self.lstm = nn.LSTM(embed_d, 64, batch_first=True)
        self.hidden2mlp = nn.Linear(64, 32)
        self.mlp2mlp = nn.Linear(32,5)
        self.dropout = nn.Dropout(0.5)
        self.data = p_content.type(torch.LongTensor)
        self.layer_dim=1
        self.hidden_dim = 64
        


    def forward(self, id_batch):
        # id_batch: use id_batch (paper ids in this batch) to obtain paper conent of this batch
        id_batch = id_batch.type(torch.LongTensor)
        #print(id_batch)
        x = self.data[id_batch]
        #print(id_batch)
        #h0 = torch.zeros(self.layer_dim, x.size(0), self.hidden_dim).requires_grad_()
        #c0 = torch.zeros(self.layer_dim, x.size(0), self.hidden_dim).requires_grad_()

        out = self.embedding(x)
        #print(out.size())
        out, (hidden, cell) = self.lstm(out)
        #print(out.size())
        out = self.dropout(out)
        out = torch.relu_(self.hidden2mlp(hidden[-1]))
        #out = self.dropout(out)
        out = self.mlp2mlp(out)
        #print(out.size())
        return out
        
    
class Text_Encoder2(nn.Module):
    def __init__(self, p_content, word_embed):
        # two input: p_content - abstract data of all papers, word_embed - pre-trained word embedding 
        super(Text_Encoder2, self).__init__()
        weight = torch.FloatTensor(word_embed)
        #print(weight.size())
        self.embedding = nn.Embedding.from_pretrained(weight)
        #self.embeddings.weight.requires_grad = False ## freeze embeddings
        self.lstm = nn.LSTM(embed_d, 64, batch_first=True)
        self.hidden2mlp = nn.Linear(64, 32)
        self.mlp2mlp = nn.Linear(32,5)
        self.dropout = nn.Dropout(0.5)
        
        self.avgpool = nn.AvgPool1d(1)
        
        self.data = p_content.type(torch.LongTensor)
        self.layer_dim=1
        self.hidden_dim = 64
        


    def forward(self, id_batch):
        # id_batch: use id_batch (paper ids in this batch) to obtain paper conent of this batch
        id_batch = id_batch.type(torch.LongTensor)
        #print(id_batch)
        x = self.data[id_batch]
        #print(id_batch)
        #h0 = torch.zeros(self.layer_dim, x.size(0), self.hidden_dim).requires_grad_()
        #c0 = torch.zeros(self.layer_dim, x.size(0), self.hidden_dim).requires_grad_()

        out = self.embedding(x)
        #print(out.size())
        out, (hidden, cell) = self.lstm(out)
        outh = torch.mean(out,1)
        #print(outh.size())
        #out = self.dropout(out)
        #hidden = hidden.permute(1,2,0)
        #pool = pool.permute(1,2,0)
        out = torch.relu_(self.hidden2mlp(outh))
        #out = self.dropout(out)
        out = self.mlp2mlp(out)
        out = torch.squeeze(out)
        #print(out.size())
        return out
        

